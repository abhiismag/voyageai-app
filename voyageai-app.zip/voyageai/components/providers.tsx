"use client";

import { ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// Create a single QueryClient instance for the entire app.
const queryClient = new QueryClient();

interface ProvidersProps {
  children: ReactNode;
}

/**
 * Providers component wraps the app with React Query's QueryClientProvider.
 * Additional context providers can be added here.
 */
export function Providers({ children }: ProvidersProps) {
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}