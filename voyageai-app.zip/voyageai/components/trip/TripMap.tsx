"use client";

import { Coordinates, Option } from "./types";
import { MapContainer, TileLayer, Marker, Polyline, Tooltip } from "react-leaflet";
import "leaflet/dist/leaflet.css";

interface TripMapProps {
  start?: Coordinates;
  options: Option[];
}

/**
 * Render a map with markers for the user's starting location and selected trip options.
 * Draws polylines from the start to each destination.
 * Note: Map tiles are loaded from OpenStreetMap; ensure network access.
 */
export function TripMap({ start, options }: TripMapProps) {
  // Default center: Europe
  const center = start ?? { lat: 50.1109, lon: 8.6821 };
  const position: [number, number] = [center.lat, center.lon];

  return (
    <div className="h-64 w-full md:h-full">
      <MapContainer
        center={position}
        zoom={5}
        scrollWheelZoom={false}
        style={{ height: "100%", width: "100%", borderRadius: "1rem" }}
      >
        <TileLayer
          attribution='© <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {start && (
          <Marker position={[start.lat, start.lon]}>
            <Tooltip direction="top" offset={[0, -10]} opacity={1}>
              You
            </Tooltip>
          </Marker>
        )}
        {options.map((option) => (
          <Marker
            key={option.id}
            position={[option.coordinates.lat, option.coordinates.lon]}
          >
            <Tooltip direction="top" offset={[0, -10]} opacity={1}>
              {option.destination}
            </Tooltip>
          </Marker>
        ))}
        {start &&
          options.map((option) => (
            <Polyline
              key={option.id}
              positions={[
                [start.lat, start.lon],
                [option.coordinates.lat, option.coordinates.lon],
              ]}
            />
          ))}
      </MapContainer>
    </div>
  );
}