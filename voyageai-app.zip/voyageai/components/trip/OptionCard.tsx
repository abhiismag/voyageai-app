"use client";

import { Option } from "./types";
import { LucideExternalLink, LucidePlus } from "lucide-react";

interface OptionCardProps {
  option: Option;
  onAdd: (option: Option) => void;
}

/**
 * Display a recommended trip option with destination, transport, price and accommodation.
 * Includes buttons to add the option to a shortlist and open the affiliate link.
 */
export function OptionCard({ option, onAdd }: OptionCardProps) {
  return (
    <div className="p-4 bg-white shadow rounded-2xl flex flex-col justify-between gap-3 border border-gray-200">
      <div className="space-y-1">
        <h3 className="text-lg font-semibold flex items-center gap-1">
          {option.destination}
        </h3>
        <p className="text-sm text-gray-600">
          <strong>Transport:</strong> {option.transport}
        </p>
        <p className="text-sm text-gray-600">
          <strong>Total price:</strong> €{option.priceTotal}
        </p>
        <p className="text-sm text-gray-600">
          <strong>Accommodation:</strong> {option.accommodation.name} (from
          €{option.accommodation.pricePerNight}/night, {option.accommodation.rating}
          ★)
        </p>
      </div>
      <div className="flex gap-3 pt-2">
        <button
          onClick={() => onAdd(option)}
          className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow"
        >
          <LucidePlus size={16} /> Add
        </button>
        <a
          href={option.accommodation.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 text-sm font-medium text-gray-800"
        >
          <LucideExternalLink size={16} /> View
        </a>
      </div>
    </div>
  );
}