"use client";

import { Option } from "./types";
import { LucideTrash2 } from "lucide-react";

interface ShortlistPanelProps {
  shortlist: Option[];
  onRemove: (id: string) => void;
}

/**
 * Display the user's shortlist of selected trip options.
 */
export function ShortlistPanel({ shortlist, onRemove }: ShortlistPanelProps) {
  if (!shortlist.length) return null;

  return (
    <div className="w-full md:w-64 p-4 bg-white border border-gray-200 rounded-2xl shadow-sm space-y-3">
      <h2 className="text-lg font-semibold">Your shortlist</h2>
      {shortlist.map((option) => (
        <div
          key={option.id}
          className="p-3 bg-gray-50 border border-gray-200 rounded-lg flex flex-col gap-1"
        >
          <div className="flex justify-between items-center">
            <span className="font-medium">{option.destination}</span>
            <button
              onClick={() => onRemove(option.id)}
              className="text-red-500 hover:text-red-600"
              aria-label={`Remove ${option.destination}`}
            >
              <LucideTrash2 size={16} />
            </button>
          </div>
          <p className="text-xs text-gray-600">
            {option.transport} – €{option.priceTotal}
          </p>
          <p className="text-xs text-gray-600">
            {option.accommodation.name}
          </p>
        </div>
      ))}
    </div>
  );
}