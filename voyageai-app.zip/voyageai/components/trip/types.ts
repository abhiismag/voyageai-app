export interface Accommodation {
  /** Name of the accommodation (e.g. hostel) */
  name: string;
  /** Price per night in euros */
  pricePerNight: number;
  /** Star rating out of 5 */
  rating: number;
  /** Affiliate URL to book the accommodation */
  url: string;
}

export interface Coordinates {
  lat: number;
  lon: number;
}

export interface Option {
  id: string;
  destination: string;
  transport: string;
  priceTotal: number;
  accommodation: Accommodation;
  coordinates: Coordinates;
  /** A brief rationale for the recommendation */
  why?: string;
}

export interface Message {
  role: "user" | "assistant";
  content: string;
}