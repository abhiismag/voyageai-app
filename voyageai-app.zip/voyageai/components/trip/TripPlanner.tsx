"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Option, Message, Coordinates } from "./types";
import { useMutation } from "@tanstack/react-query";
import { OptionCard } from "./OptionCard";
import { ShortlistPanel } from "./ShortlistPanel";
import { TripMap } from "./TripMap";

interface UserForm {
  start?: string;
  destination?: string;
  preferences?: string;
  budget?: string;
  dates?: {
    start: string;
    end: string;
  };
}

type Step =
  | "ask_start"
  | "ask_destination"
  | "ask_preferences"
  | "ask_budget"
  | "ask_dates"
  | "show_options";

/**
 * TripPlanner provides a conversational interface for students to plan a trip.
 * It guides the user through a series of steps, then suggests a few static options.
 */
export function TripPlanner() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi! I can help you plan a budget-friendly trip. Where are you starting from?",
    },
  ]);
  const [form, setForm] = useState<UserForm>({});
  const [step, setStep] = useState<Step>("ask_start");
  const [options, setOptions] = useState<Option[]>([]);
  const [shortlist, setShortlist] = useState<Option[]>([]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);

  /**
   * Mutation to fetch recommendations from the API. It sends the current
   * conversation and form data to the backend. On success, it updates
   * assistant messages and suggested options.
   */
  const generateMutation = useMutation(
    async (payload: { messages: Message[]; form: UserForm }) => {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("Failed to generate");
      return (await res.json()) as { reply: string; options: Option[] };
    },
    {
      onSuccess: (data) => {
        // Append assistant reply and update options
        setMessages((msgs) => [...msgs, { role: "assistant", content: data.reply }]);
        setOptions(data.options);
        setStep("show_options");
        setTyping(false);
      },
      onError: () => {
        setMessages((msgs) => [
          ...msgs,
          {
            role: "assistant",
            content: "Sorry, something went wrong while fetching options. Please try again.",
          },
        ]);
        setTyping(false);
      },
    }
  );

  /**
   * Append a message to the conversation with a small typing delay.
   */
  function addAssistantMessage(text: string) {
    setTyping(true);
    // Simulate typing delay
    setTimeout(() => {
      setMessages((msgs) => [...msgs, { role: "assistant", content: text }]);
      setTyping(false);
    }, 800);
  }


  /**
   * Handle submission of the user's input.
   */
  function handleSubmit() {
    const text = input.trim();
    if (!text) return;
    // Append user's message
    setMessages((msgs) => [...msgs, { role: "user", content: text }]);
    setInput("");

    // Process input based on the current step
    switch (step) {
      case "ask_start": {
        setForm((data) => ({ ...data, start: text }));
        setStep("ask_destination");
        addAssistantMessage(
          `Great! Where would you like to go? (e.g. Vienna or Munich)`
        );
        break;
      }
      case "ask_destination": {
        setForm((data) => ({ ...data, destination: text }));
        setStep("ask_preferences");
        addAssistantMessage(
          `Got it. Any preferences? For example, “cheap”, “hostel”, “nightlife”.`
        );
        break;
      }
      case "ask_preferences": {
        setForm((data) => ({ ...data, preferences: text }));
        setStep("ask_budget");
        addAssistantMessage(
          `Thanks! What's your approximate total budget in euros?`
        );
        break;
      }
      case "ask_budget": {
        setForm((data) => ({ ...data, budget: text }));
        setStep("ask_dates");
        addAssistantMessage(
          `When do you plan to travel? Please specify start and end dates (e.g. 2025-05-01 to 2025-05-04).`
        );
        break;
      }
      case "ask_dates": {
        // Attempt to parse dates: look for two dates separated by to or - or –
        const parts = text.split(/to|-|–/).map((p) => p.trim());
        if (parts.length >= 2) {
          setForm((data) => ({ ...data, dates: { start: parts[0], end: parts[1] } }));
        }
        // Kick off the API call for recommendations. We set typing to true
        // until the mutation resolves. The actual assistant reply will be
        // injected in the onSuccess handler of the mutation.
        setTyping(true);
        generateMutation.mutate({ messages: [...messages, { role: "user", content: text }], form: { ...form, dates: { start: parts[0], end: parts[1] } } });
        break;
      }
      case "show_options": {
        // In this state, we treat further input as chat; we just echo a friendly response
        addAssistantMessage(
          `Feel free to select an option or ask another question. I can refine your trip if needed!`
        );
        break;
      }
    }
  }

  /**
   * Add an option to the shortlist if it's not already present.
   */
  function handleAdd(option: Option) {
    setShortlist((current) => {
      if (current.find((o) => o.id === option.id)) return current;
      return [...current, option];
    });
  }

  /**
   * Remove an option from the shortlist by id.
   */
  function handleRemove(id: string) {
    setShortlist((current) => current.filter((o) => o.id !== id));
  }

  // Determine start coordinates for the map using a simple lookup for a few cities
  const startCoordinates: Coordinates | undefined = (() => {
    const city = form.start?.trim().toLowerCase();
    const map: Record<string, Coordinates> = {
      berlin: { lat: 52.5208, lon: 13.4095 },
      munich: { lat: 48.1351, lon: 11.582 },
      vienna: { lat: 48.2082, lon: 16.3738 },
      saarbrücken: { lat: 49.2402, lon: 6.9969 },
    };
    return city ? map[city] : undefined;
  })();

  return (
    <div className="flex flex-col md:flex-row h-full">
      {/* Chat and options section */}
      <div className="flex-1 flex flex-col border-r border-gray-200 h-full overflow-y-auto">
        <div className="flex-1 p-4 space-y-3">
          <AnimatePresence>
            {messages.map((msg, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.2 }}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-xs md:max-w-md p-3 rounded-2xl shadow-sm text-sm whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-blue-600 text-white rounded-br-none"
                      : "bg-gray-100 text-gray-800 rounded-bl-none"
                  }`}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {typing && (
              <motion.div
                key="typing"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.2 }}
                className="flex justify-start"
              >
                <div className="max-w-xs md:max-w-md p-3 rounded-2xl shadow-sm bg-gray-100 text-gray-800 rounded-bl-none italic">
                  ...
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {/* Input bar */}
        <div className="p-4 border-t border-gray-200 flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            placeholder="Type your message..."
            className="flex-1 bg-white border border-gray-300 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSubmit}
            disabled={!input.trim() || typing}
            className="px-4 py-2 rounded-full bg-blue-600 text-white text-sm font-medium shadow disabled:opacity-50"
          >
            Send
          </button>
        </div>
        {/* Options */}
        {step === "show_options" && (
          <div className="p-4 space-y-4">
            {options.map((option) => (
              <OptionCard key={option.id} option={option} onAdd={handleAdd} />
            ))}
          </div>
        )}
      </div>
      {/* Sidebar for map and shortlist */}
      <aside className="hidden md:block md:w-80 p-4 space-y-4">
        <ShortlistPanel shortlist={shortlist} onRemove={handleRemove} />
        <TripMap start={startCoordinates} options={shortlist} />
      </aside>
    </div>
  );
}