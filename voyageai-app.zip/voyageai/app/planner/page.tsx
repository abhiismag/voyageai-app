import { TripPlanner } from "@/components/trip/TripPlanner";

export default function PlannerPage() {
  return (
    <main className="flex-1 h-[calc(100vh-4rem)]">
      <TripPlanner />
    </main>
  );
}