import Link from "next/link";
import { LucidePlane, LucideMapPin } from "lucide-react";

export default function HomePage() {
  return (
    <main className="flex-1 flex flex-col items-center justify-center px-4 py-16 text-center space-y-8">
      <div className="max-w-2xl space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold leading-tight">
          Your Student Travel Concierge
        </h1>
        <p className="text-lg md:text-xl text-gray-600">
          VoyageAI helps you discover budget-friendly trips across Europe. Describe
          your ideal getaway, and our AI will suggest real train and flight
          options, affordable hostels and experiences—grounded in real data.
        </p>
        <div className="flex justify-center gap-4 pt-4">
          <Link
            href="/planner"
            className="inline-flex items-center gap-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 font-medium shadow-md transition-all"
          >
            <LucideMapPin size={20} /> Start planning
          </Link>
          <Link
            href="#learn"
            className="inline-flex items-center gap-2 rounded-full border border-gray-300 bg-white hover:bg-gray-50 text-gray-800 px-6 py-3 font-medium shadow-sm transition-all"
          >
            <LucidePlane size={20} /> Learn more
          </Link>
        </div>
      </div>
      <section id="learn" className="max-w-3xl text-left space-y-6 pt-16">
        <h2 className="text-2xl font-semibold">How it works</h2>
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          <li>
            <strong>Chat about your trip:</strong> Tell VoyageAI where you are,
            when you want to go and what you care about. Our chat UI makes it
            feel like texting a friend.
          </li>
          <li>
            <strong>Get real suggestions:</strong> We combine curated travel
            datasets with an open-source LLM to propose flights, trains and
            hostels that fit your budget and preferences.
          </li>
          <li>
            <strong>Book through partners:</strong> Every recommendation
            includes a deep link to trusted providers like Deutsche Bahn,
            Ryanair and Hostelworld with our affiliate code built in.
          </li>
          <li>
            <strong>Save trips:</strong> Sign in to save itineraries and come
            back later. Your data stays in Europe and you control your
            information.
          </li>
        </ul>
      </section>
    </main>
  );
}