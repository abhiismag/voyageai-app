import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

interface Accommodation {
  name: string;
  pricePerNight: number;
  rating: number;
  url: string;
}

interface Option {
  id: string;
  destination: string;
  transport: string;
  priceTotal: number;
  accommodation: Accommodation;
  coordinates: { lat: number; lon: number };
  why?: string;
}

interface GenerateRequestBody {
  messages: { role: string; content: string }[];
  form: {
    start?: string;
    destination?: string;
    preferences?: string;
    budget?: string;
    dates?: { start: string; end: string };
  };
}

/**
 * Stub implementation of a generate endpoint. In a real application this
 * function would call an LLM (e.g. Llama 3 via a hosted API or OpenAI) and
 * integrate real travel data using retrieval-augmented generation. It uses the
 * last user preferences to produce a friendly response and a set of options.
 */
export async function POST(req: NextRequest) {
  try {
    const body: GenerateRequestBody = await req.json();
    const { form } = body;
    const dest = form.destination?.trim().toLowerCase() ?? "";

    // Minimal static dataset. In production this would be replaced with calls
    // to travel APIs (DB, Ryanair, Hostelworld) and an LLM to craft the
    // narrative.
    const allOptions: Option[] = [
      {
        id: "vienna-flight",
        destination: "Vienna",
        transport: "Flight",
        priceTotal: 120,
        accommodation: {
          name: "Wombats City Hostel Vienna",
          pricePerNight: 35,
          rating: 4.5,
          url: "https://www.hostelworld.com/hosteldetails.php/Wombats-City-Hostel-Vienna-The-Naschmarkt/Vienna/45015",
        },
        coordinates: { lat: 48.2082, lon: 16.3738 },
        why: "Cheap flight from Berlin with a top-rated hostel near the city centre.",
      },
      {
        id: "munich-train",
        destination: "Munich",
        transport: "Train",
        priceTotal: 80,
        accommodation: {
          name: "Euro Youth Hotel Munich",
          pricePerNight: 28,
          rating: 4.4,
          url: "https://www.hostelworld.com/hosteldetails.php/Euro-Youth-Hostel-Munich/Munich/14529",
        },
        coordinates: { lat: 48.1351, lon: 11.582 },
        why: "Direct train ride with affordable lodging near the Hauptbahnhof.",
      },
      {
        id: "vienna-nightbus",
        destination: "Vienna",
        transport: "Night Bus",
        priceTotal: 60,
        accommodation: {
          name: "a&o Wien Hauptbahnhof",
          pricePerNight: 25,
          rating: 4.0,
          url: "https://www.hostelworld.com/hosteldetails.php/A-and-O-Wien-Hauptbahnhof/Vienna/73481",
        },
        coordinates: { lat: 48.2082, lon: 16.3738 },
        why: "Save money by travelling overnight and stay near Vienna's train station.",
      },
    ];
    const filtered = dest
      ? allOptions.filter((opt) => opt.destination.toLowerCase().includes(dest))
      : allOptions;

    // Compose a human-like chat reply summarising the options.
    const destinations = Array.from(new Set(filtered.map((o) => o.destination)));
    const list = destinations.join(" or ");
    const reply =
      filtered.length > 0
        ? `I've found a few good options for you: ${list}. Each includes travel and hostel suggestions below. Let me know which one you like!`
        : `Sorry, I couldn't find any options for that destination. Try another city or adjust your preferences.`;

    return NextResponse.json({ reply, options: filtered });
  } catch (err) {
    return NextResponse.json({ error: "Failed to generate" }, { status: 500 });
  }
}