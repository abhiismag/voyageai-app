import "./globals.css";
import type { Metadata } from "next";
import { Providers } from "@/components/providers";

export const metadata: Metadata = {
  title: {
    default: "VoyageAI – Student Travel Concierge",
    template: "%s | VoyageAI",
  },
  description:
    "Plan budget-friendly student trips across Europe with an AI-powered travel concierge. Get real itinerary suggestions for trains, flights and hostels.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}