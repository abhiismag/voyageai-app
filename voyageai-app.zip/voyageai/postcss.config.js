/**
 * PostCSS configuration for VoyageAI.
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};