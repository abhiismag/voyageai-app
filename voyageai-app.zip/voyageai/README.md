# VoyageAI: Student Travel Concierge

VoyageAI is an AI‑powered web application that helps students plan budget‑friendly trips across Europe. It combines chat‑based trip planning with real travel data and integrates affiliate booking links for flights, trains and hostels. This repository contains the source code for the MVP, refactored from a Base44 prototype into a modern Next.js stack.

## Features

- **Chat‑centric interface:** A conversational UI guides users through choosing their origin, destination, preferences, budget and dates. Messages animate in like a messenger app for a natural feel.
- **LLM‑powered suggestions:** The frontend sends the chat history and form data to a `/api/generate` endpoint. In production this would call an open‑source LLM (e.g. Llama 3) with retrieval‑augmented inputs (train schedules, flight prices, hostel availability). The current stub returns static examples for the Berlin–Munich–Vienna corridor.
- **Option cards and shortlist:** Users can review recommended options with transport and accommodation details, add favourites to a shortlist and visualise them on an interactive map.
- **Firebase integration:** A `lib/firebase.ts` helper sets up Firebase Authentication, Firestore and Storage. Use this to persist user profiles and itineraries (firestore rules should restrict data to the owning user).
- **Tailwind CSS:** The UI is styled with Tailwind for rapid iteration and consistent design.
- **Next.js App Router:** Pages live under `app/` with serverless API routes under `app/api`.

## Roadmap alignment

This MVP loosely follows the CTO‑level technical roadmap:

- **Phase 1:** A web‑based chat concierge focusing on one travel corridor. The static examples mirror a Berlin–Vienna/Munich route. Firebase Hosting and Firestore (EU region) are expected in deployment.
- **RAG and open‑source LLMs:** The `/api/generate` endpoint is designed to be replaced with a retrieval‑augmented pipeline that queries travel APIs (OSDM for trains, Ryanair API, hostel listings) and then calls an open‑source language model. See `app/api/generate/route.ts` for where to plug in your model.
- **Compliance by design:** All user data should be stored in the EU and privacy consent should be integrated at onboarding. A `.env.example` file is provided for secure configuration.

## Development

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Configure environment variables**
   Create a `.env.local` file based on `.env.example` and fill in your Firebase project details and any LLM API keys you plan to use.

3. **Run locally**
   ```bash
   npm run dev
   ```
   Visit `http://localhost:3000` to use the chat and planner interface.

4. **Deploy**
   - **Firebase Hosting:** Run `firebase login` then `firebase init hosting` and deploy with `firebase deploy`. Ensure the hosting region is set to Europe.
   - **Vercel:** Connect your GitHub repo to Vercel and set the environment variables in the dashboard. Vercel will handle builds and deployments automatically.

## Future improvements

- Replace the stub in `/api/generate` with calls to a retrieval pipeline and a real LLM to produce context‑aware, human‑like responses.
- Persist chat history and user preferences in Firestore; show past itineraries on a dashboard.
- Add authentication UI and student verification (Phase 2).
- Introduce payment / affiliate tracking and compliance features.